- 👋 Hi, I’m @AbijithT2003
- 👀 I’m interested in c/cpp and verilog coding...
- 🌱 I’m currently doing Bachelor in TECH in electronics and communication
- 💞️ I’m looking to collaborate on literraly anything related to c/verilog
- 📫 How to reach me stinsonb380@gmail.com
- 😄 Pronouns: he/him
- ⚡ Fun fact: fk pronouns

<!---
AbijithT2003/AbijithT2003 is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
